package pointweaver;

import com.ctre.phoenix6.swerve.SwerveDrivetrain;
import com.ctre.phoenix6.swerve.SwerveModule.DriveRequestType;
import com.ctre.phoenix6.swerve.SwerveModule.SteerRequestType;
import com.ctre.phoenix6.swerve.SwerveRequest;
import com.ctre.phoenix6.swerve.SwerveRequest.ForwardPerspectiveValue;

import org.wpilib.math.geometry.Pose2d;
import org.wpilib.math.geometry.Rotation2d;
import org.wpilib.math.kinematics.ChassisVelocities;
import org.wpilib.system.Timer;

import pointweaver.core.FollowerCore;
import pointweaver.core.PathDefinition;

/**
 * Follows one path on the configured CTRE drivetrain. Shaped like an OpMode:
 * {@link #start()} once, {@link #update()} every loop, {@link #stop()} at the end.
 * Get one from {@link PointWeaver#follower(String)}.
 */
public final class PathFollower {
    private final FollowerCore core;
    private final SwerveDrivetrain<?, ?, ?> drivetrain;
    private final WeaverTelemetry telemetry;
    private final SwerveRequest.FieldCentricFacingAngle drive;
    private final SwerveRequest.RobotCentric idle = new SwerveRequest.RobotCentric()
        .withVelocityX(0).withVelocityY(0).withRotationalRate(0);
    private boolean started;
    /** Telemetry says this path is running (so "ended" is published once, not every loop after). */
    private boolean running;

    PathFollower(PathDefinition path, SwerveDrivetrain<?, ?, ?> drivetrain, PointWeaverConfig config, WeaverTelemetry telemetry) {
        this.core = new FollowerCore(path, config.toSettings(), PointWeaver::fireEvent);
        this.drivetrain = drivetrain;
        this.telemetry = telemetry;
        this.drive = new SwerveRequest.FieldCentricFacingAngle()
            .withDriveRequestType(DriveRequestType.Velocity)
            .withSteerRequestType(SteerRequestType.MotionMagicExpo)
            .withForwardPerspective(ForwardPerspectiveValue.BlueAlliance)
            .withHeadingPID(config.headingKp, config.headingKi, config.headingKd);
    }

    /**
     * Begin the path from where the robot is now (resetting odometry first if the path asks for it).
     * Starts from the robot's current velocity, so chaining onto a moving robot doesn't jolt it.
     */
    public void start() {
        var state = drivetrain.getState();
        Pose2d pose = state.Pose;
        FollowerCore.Pose reset = core.resetPose(pose.getRotation().getDegrees());
        if (reset != null) {
            pose = new Pose2d(reset.x, reset.y, Rotation2d.fromDegrees(reset.headingDeg));
            drivetrain.resetPose(pose);
        }
        // measured velocity is robot-relative; the follower works in field coordinates
        ChassisVelocities field = state.Velocity.toFieldRelative(state.Pose.getRotation());
        core.start(pose.getX(), pose.getY(), pose.getRotation().getDegrees(), field.vx, field.vy, Timer.getTimestamp());
        started = true;
        running = true;
        telemetry.pathStarted(core.path());
    }

    /** Drive for one loop. Starts the path first if {@link #start()} wasn't called. */
    public void update() {
        if (!started) start();
        var state = drivetrain.getState();
        Pose2d pose = state.Pose;
        // braking uses what the robot is actually doing, not just what it was told
        ChassisVelocities field = state.Velocity.toFieldRelative(pose.getRotation());
        FollowerCore.Output out = core.update(pose.getX(), pose.getY(), pose.getRotation().getDegrees(),
            field.vx, field.vy, Timer.getTimestamp());
        if (out.finished) {
            drivetrain.setControl(idle);
        } else {
            drivetrain.setControl(drive
                .withVelocityX(out.vx)
                .withVelocityY(out.vy)
                .withTargetDirection(Rotation2d.fromDegrees(out.headingDeg))
                // the turn rate the path asks for, so the heading P controller only corrects errors instead of lagging
                .withTargetRateFeedforward(Math.toRadians(out.headingRateDegPerSec)));
        }
        telemetry.update(pose, core.path(), out);
        if (out.finished) ended();
    }

    /** True once the last point is reached (or the path couldn't be loaded). */
    public boolean isFinished() {
        return core.isFinished();
    }

    /** Stop driving now. Safe to call any time, including after the path finished. */
    public void stop() {
        core.cancel();
        started = false;
        drivetrain.setControl(idle);
        ended();
    }

    private void ended() {
        if (!running) return;
        running = false;
        telemetry.pathEnded();
    }

    /** The path's name. */
    public String name() {
        return core.path().name;
    }
}
